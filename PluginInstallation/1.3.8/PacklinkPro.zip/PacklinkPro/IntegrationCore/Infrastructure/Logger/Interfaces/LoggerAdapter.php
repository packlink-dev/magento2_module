<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Interfaces;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\LogData;

/**
 * Interface LoggerAdapter.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Interfaces
 */
interface LoggerAdapter
{
    /**
     * Log message in system
     *
     * @param LogData $data
     */
    public function logMessage(LogData $data);
}
