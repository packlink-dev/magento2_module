<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class TaskRunnerStatusStorageUnavailableException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerStatusStorageUnavailableException extends BaseException
{
}
