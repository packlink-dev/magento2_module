<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class FixedPriceValueOutOfBoundsException
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Exceptions
 */
class FixedPriceValueOutOfBoundsException extends BaseException
{
}