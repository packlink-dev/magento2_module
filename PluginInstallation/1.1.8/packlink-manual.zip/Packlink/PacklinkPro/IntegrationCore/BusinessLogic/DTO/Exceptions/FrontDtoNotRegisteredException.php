<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class FrontDtoNotRegisteredException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions
 */
class FrontDtoNotRegisteredException extends BaseException
{
}
