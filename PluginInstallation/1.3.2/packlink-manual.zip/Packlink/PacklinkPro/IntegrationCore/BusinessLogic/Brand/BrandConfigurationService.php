<?php


namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Brand;

use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Brand\DTO\BrandConfiguration;

/**
 * Interface BrandConfigurationService
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Brand
 */
interface BrandConfigurationService
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;

    /**
     * Retrieves BrandConfiguration.
     *
     * @return BrandConfiguration
     */
    public function get();
}
