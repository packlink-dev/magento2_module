<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions;

/**
 * Class HttpCommunicationException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Exceptions
 */
class HttpCommunicationException extends HttpBaseException
{

}
