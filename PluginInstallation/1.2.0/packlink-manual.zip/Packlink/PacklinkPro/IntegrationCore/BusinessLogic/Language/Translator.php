<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Language;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Language\Interfaces\TranslationService as TranslationServiceInterface;

/**
 * Class Translator.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Language
 */
class Translator
{
    /**
     * @var TranslationServiceInterface
     */
    protected static $translationService;

    /**
     * Translates provided string.
     *
     * @param string $key Key to be translated.
     * @param array $arguments List of translation arguments.
     *
     * @return string Translated string.
     */
    public static function translate($key, array $arguments = array())
    {
        return static::getTranslationService()->translate($key, $arguments);
    }

    /**
     * Retrieves translation service.
     *
     * @return TranslationServiceInterface
     */
    protected static function getTranslationService()
    {
        if (static::$translationService === null) {
            static::$translationService = ServiceRegister::getService(TranslationServiceInterface::CLASS_NAME);
        }

        return static::$translationService;
    }
}
