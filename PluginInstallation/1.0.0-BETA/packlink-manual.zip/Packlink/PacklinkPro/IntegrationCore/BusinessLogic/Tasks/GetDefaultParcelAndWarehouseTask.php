<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Task;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\User\UserAccountService;

/**
 * Class GetDefaultParcelAndWarehouseTask
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks
 */
class GetDefaultParcelAndWarehouseTask extends Task
{
    /**
     * Runs task logic.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpBaseException
     */
    public function execute()
    {
        /** @var UserAccountService $userAccountService */
        $userAccountService = ServiceRegister::getService(UserAccountService::CLASS_NAME);

        $userAccountService->setDefaultParcel(true);
        $this->reportProgress(50);

        $userAccountService->setWarehouseInfo(true);
        $this->reportProgress(100);
    }
}
