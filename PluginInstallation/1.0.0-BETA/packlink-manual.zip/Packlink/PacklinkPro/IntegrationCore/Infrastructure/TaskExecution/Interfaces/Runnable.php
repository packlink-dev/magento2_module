<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces;

/**
 * Interface Runnable.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces
 */
interface Runnable extends \Serializable
{
    /**
     * Starts runnable run logic
     */
    public function run();
}
