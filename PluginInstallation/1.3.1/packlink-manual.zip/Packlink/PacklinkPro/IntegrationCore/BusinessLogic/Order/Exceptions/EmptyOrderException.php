<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class EmptyOrderException
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Exceptions
 */
class EmptyOrderException extends BaseException
{
}