<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions;

/**
 * Class HttpRequestException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Exceptions
 */
class HttpRequestException extends HttpBaseException
{

}
