<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\OAuth\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

class InvalidOAuthStateException extends BaseException
{

}