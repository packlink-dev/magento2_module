<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Draft;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Data\DataTransferObject;

/**
 * Class Customs
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Draft
 */
class Customs extends DataTransferObject
{
    /**
     * @var string
     */
    public $customsInvoiceId;

    public function toArray()
    {
        return array(
            'customs_invoice_id' => $this->customsInvoiceId,
        );
    }
}
