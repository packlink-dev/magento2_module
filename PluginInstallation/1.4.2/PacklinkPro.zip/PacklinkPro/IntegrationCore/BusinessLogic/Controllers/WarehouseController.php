<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\Country;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\WarehouseCountryService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\WarehouseService;

/**
 * Class WarehouseController
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class WarehouseController
{
    /**
     * Warehouse service.
     *
     * @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\WarehouseService
     */
    protected $service;

    /**
     * WarehouseController constructor.
     */
    public function __construct()
    {
        $this->service = ServiceRegister::getService(WarehouseService::CLASS_NAME);
    }

    /**
     * Provides warehouse data.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\Warehouse | null
     */
    public function getWarehouse()
    {
        return $this->service->getWarehouse();
    }

    /**
     * Updates warehouse.
     *
     * @param array $data
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\Warehouse
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions\QueueStorageUnavailableException
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoNotRegisteredException
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException
     */
    public function updateWarehouse(array $data)
    {
        return $this->service->updateWarehouseData($data);
    }

    /**
     * Returns available countries for warehouse location.
     *
     * @return Country[]
     */
    public function getWarehouseCountries()
    {
        /** @var WarehouseCountryService $countryService */
        $countryService = ServiceRegister::getService(WarehouseCountryService::CLASS_NAME);

        return $countryService->getSupportedCountries(false);
    }
}