<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO\DashboardStatus;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\FrontDtoFactory;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingMethodService;

/**
 * Class DashboardController.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class DashboardController
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
    /**
     * Shipping method service.
     *
     * @var ShippingMethodService
     */
    private $shippingMethodService;
    /**
     * Configuration instance.
     *
     * @var Configuration
     */
    private $configuration;

    /**
     * DashboardController constructor.
     */
    public function __construct()
    {
        $this->configuration = ServiceRegister::getService(Configuration::CLASS_NAME);
        $this->shippingMethodService = ServiceRegister::getService(ShippingMethodService::CLASS_NAME);
    }

    /**
     * Returns Dashboard status object with configuration flags.
     *
     * @return DashboardStatus Dashboard status.
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoNotRegisteredException
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException
     */
    public function getStatus()
    {
        /** @noinspection PhpIncompatibleReturnTypeInspection */
        return FrontDtoFactory::get(
            DashboardStatus::CLASS_KEY,
            array(
                'isParcelSet' => $this->configuration->getDefaultParcel() !== null,
                'isWarehouseSet' => $this->configuration->getDefaultWarehouse() !== null,
                'isShippingMethodSet' => $this->shippingMethodService->isAnyMethodActive(),
            )
        );
    }
}
