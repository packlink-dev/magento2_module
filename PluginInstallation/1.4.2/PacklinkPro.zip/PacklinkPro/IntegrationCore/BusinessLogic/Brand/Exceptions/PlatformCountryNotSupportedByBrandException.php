<?php


namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Brand\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class PlatformCountryNotSupportedByBrandException
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Brand\Exceptions
 */
class PlatformCountryNotSupportedByBrandException extends BaseException
{

}