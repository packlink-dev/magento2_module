<?php
/**
 * @package    Packlink_PacklinkPro
 * @author     Packlink Shipping S.L.
 * @copyright  2022 Packlink
 */

namespace Packlink\PacklinkPro\Block\Adminhtml\Content;

/**
 * Class Login
 *
 * @package Packlink\PacklinkPro\Block\Adminhtml\Content
 */
class Login extends Content
{
}
