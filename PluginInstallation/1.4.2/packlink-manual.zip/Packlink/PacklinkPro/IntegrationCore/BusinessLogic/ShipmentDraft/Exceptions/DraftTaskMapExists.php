<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShipmentDraft\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class DraftTaskMapAlreadyExists.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShipmentDraft\Exceptions
 */
class DraftTaskMapExists extends BaseException
{
}
