<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Utility;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Configuration\Configuration;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;

/**
 * Class UrlService
 *
 * @package Packlink\PacklinkPro\IntegrationCore\DemoUI\Repository
 */
class UrlService
{
    /**
     * Returns locale for URLs in uppercase format.
     *
     * @return string
     */
    public static function getUrlLocaleKey()
    {
        $locale = 'EN';

        /** @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration $configService */
        $configService = ServiceRegister::getService(Configuration::CLASS_NAME);
        $userInfo = $configService->getUserInfo();
        $currentLang = $configService::getUICountryCode();

        if ($userInfo !== null) {
            $locale = $userInfo->country;
        } elseif ($currentLang) {
            $locale = strtoupper($currentLang);
        }

        return $locale;
    }
}
