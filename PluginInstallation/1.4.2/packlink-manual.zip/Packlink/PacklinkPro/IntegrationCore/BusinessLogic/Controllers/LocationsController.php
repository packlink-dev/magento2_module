<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Exception;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Logger;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Location\LocationService;

/**
 * Class LocationsController
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class LocationsController
{
    /**
     * Location service.
     *
     * @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Location\LocationService
     */
    protected $service;

    /**
     * LocationsController constructor.
     */
    public function __construct()
    {
        $this->service = ServiceRegister::getService(LocationService::CLASS_NAME);
    }

    /**
     * Retrieves locations.
     *
     * @param array $query Associative array in the following format ['query' => '...', 'country' => '...'].
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\LocationInfo[]
     */
    public function searchLocations(array $query)
    {
        if (empty($query['query']) || empty($query['country'])) {
            return array();
        }

        try {
            $result = $this->service->searchLocations($query['country'], $query['query']);
        } catch (Exception $e) {
            Logger::logError('Location search failed.', 'Core', $e->getTrace());

            $result = array();
        }

        return $result;
    }
}