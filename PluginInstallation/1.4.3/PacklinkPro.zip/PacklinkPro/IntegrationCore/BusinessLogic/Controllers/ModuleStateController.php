<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO\ModuleState;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ParcelInfo;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\Warehouse;
use Packlink\PacklinkPro\IntegrationCore\DemoUI\Services\BusinessLogic\ConfigurationService;

/**
 * Class ModuleStateController
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class ModuleStateController
{
    /**
     * Gets current state of the application.
     *
     * @return ModuleState
     */
    public function getCurrentState()
    {
        /** @var ConfigurationService $configService */
        $configService = ServiceRegister::getService(Configuration::CLASS_NAME);

        /** @var string $apiToken */
        $apiToken = $configService->getAuthorizationToken();

        /** @var ParcelInfo|null $defaultParcel */
        $defaultParcel = $configService->getDefaultParcel();

        /** @var Warehouse|null $defaultWarehouse */
        $defaultWarehouse = $configService->getDefaultWarehouse();

        $result = new ModuleState();

        if (empty($apiToken)) {
            $result->state = ModuleState::LOGIN_STATE;

        } else if ($defaultParcel === null || $defaultWarehouse === null) {
            $result->state = ModuleState::ONBOARDING_STATE;

        } else {
            $result->state = ModuleState::SERVICES_STATE;
        }

        return $result;
    }
}
