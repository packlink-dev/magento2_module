<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\TaskEvents;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Events\Event;

/**
 * Class TickEvent.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Scheduler
 */
class TickEvent extends Event
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
}
