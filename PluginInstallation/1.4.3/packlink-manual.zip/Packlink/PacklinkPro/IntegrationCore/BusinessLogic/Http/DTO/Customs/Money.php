<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Customs;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Data\DataTransferObject;

/**
 * Class Money
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Customs
 */
class Money extends DataTransferObject
{
    /**
     * @var string
     */
    public $currency;
    /**
     * @var float
     */
    public $value;

    /**
     * @inheritDoc
     */
    public static function fromArray(array $data)
    {
        $result = new static();

        $result->currency = static::getDataValue($data, 'currency');
        $result->value = static::getDataValue($data, 'value', 0);

        return $result;
    }

    /**
     * @inheritDoc
     */
    public function toArray()
    {
        return array(
            'currency' => $this->currency,
            'value' => $this->value,
        );
    }
}