<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\CountryLabels\Interfaces\CountryService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Utility\UrlService;

/**
 * Class ConfigurationController.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class ConfigurationController
{
    /**
     * @return string
     */
    public function getHelpLink()
    {
        $lang = UrlService::getUrlLocaleKey();

        /** @var CountryService $countryService */
        $countryService = ServiceRegister::getService(CountryService::CLASS_NAME);

        return $countryService->getLabel(strtolower($lang), 'configuration.helpUrl');
    }
}
