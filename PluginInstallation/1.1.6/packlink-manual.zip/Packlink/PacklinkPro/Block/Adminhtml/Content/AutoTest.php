<?php
/**
 * @package    Packlink_PacklinkPro
 * @author     Packlink Shipping S.L.
 * @copyright  2020 Packlink
 */

namespace Packlink\PacklinkPro\Block\Adminhtml\Content;

/**
 * Class AutoTest.
 *
 * @package Packlink\PacklinkPro\Block\Adminhtml\Content
 */
class AutoTest extends Content
{
}
