<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\AutoTest\AutoTestService;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\HttpClient;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\TaskEvents\TickEvent;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Events\EventBus;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DashboardController;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO\DashboardStatus;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\ShippingMethodController;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\Country;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\CountryService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\WarehouseCountryService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\FrontDtoFactory;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\ValidationError;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\FileResolver\FileResolverService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ParcelInfo;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\CountryLabels\Interfaces\CountryService as LabelServiceInterface;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\CountryLabels\CountryService as CountryLabelService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Location\LocationService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\OrderService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\OrderShipmentDetails\OrderShipmentDetailsService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\RegistrationLegalPolicy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\RegistrationRequest;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\RegistrationService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Scheduler\ScheduleTickHandler;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShipmentDraft\OrderSendDraftTaskMapService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShipmentDraft\ShipmentDraftService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Models\ShippingPricePolicy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\PackageTransformer;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingMethodService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\User\UserAccountService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\Warehouse;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\WarehouseService;

/**
 * Class BootstrapComponent.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic
 */
class BootstrapComponent extends \Packlink\PacklinkPro\IntegrationCore\Infrastructure\BootstrapComponent
{
    /**
     * Initializes infrastructure components.
     */
    public static function init()
    {
        parent::init();

        static::initDtoRegistry();
    }

    /**
     * Initializes services and utilities.
     */
    protected static function initServices()
    {
        parent::initServices();

        ServiceRegister::registerService(
            Proxy::CLASS_NAME,
            function () {
                /** @var Configuration $config */
                $config = ServiceRegister::getService(Configuration::CLASS_NAME);
                /** @var HttpClient $client */
                $client = ServiceRegister::getService(HttpClient::CLASS_NAME);

                return new Proxy($config, $client);
            }
        );

        ServiceRegister::registerService(
            UserAccountService::CLASS_NAME,
            function () {
                return UserAccountService::getInstance();
            }
        );

        ServiceRegister::registerService(
            ShippingMethodService::CLASS_NAME,
            function () {
                return ShippingMethodService::getInstance();
            }
        );

        ServiceRegister::registerService(
            OrderService::CLASS_NAME,
            function () {
                return OrderService::getInstance();
            }
        );

        ServiceRegister::registerService(
            DashboardController::CLASS_NAME,
            function () {
                return new DashboardController();
            }
        );

        ServiceRegister::registerService(
            ShippingMethodController::CLASS_NAME,
            function () {
                return new ShippingMethodController();
            }
        );

        ServiceRegister::registerService(
            LocationService::CLASS_NAME,
            function () {
                return LocationService::getInstance();
            }
        );

        ServiceRegister::registerService(
            PackageTransformer::CLASS_NAME,
            function () {
                return PackageTransformer::getInstance();
            }
        );

        ServiceRegister::registerService(
            OrderShipmentDetailsService::CLASS_NAME,
            function () {
                return OrderShipmentDetailsService::getInstance();
            }
        );

        ServiceRegister::registerService(
            OrderSendDraftTaskMapService::CLASS_NAME,
            function () {
                return OrderSendDraftTaskMapService::getInstance();
            }
        );

        ServiceRegister::registerService(
            ShipmentDraftService::CLASS_NAME,
            function () {
                return ShipmentDraftService::getInstance();
            }
        );

        ServiceRegister::registerService(
            WarehouseService::CLASS_NAME,
            function () {
                return WarehouseService::getInstance();
            }
        );

        ServiceRegister::registerService(
            CountryService::CLASS_NAME,
            function () {
                return CountryService::getInstance();
            }
        );

        ServiceRegister::registerService(
            WarehouseCountryService::CLASS_NAME,
            function () {
                return WarehouseCountryService::getInstance();
            }
        );

        ServiceRegister::registerService(
            RegistrationService::CLASS_NAME,
            function () {
                return RegistrationService::getInstance();
            }
        );

        ServiceRegister::registerService(
            FileResolverService::CLASS_NAME,
            function () {
                return new FileResolverService(
                    array(
                        __DIR__ . '/../Brands/Packlink/Resources/countries',
                        __DIR__ . '/Resources/countries',
                    )
                );
            }
        );

        ServiceRegister::registerService(
            LabelServiceInterface::CLASS_NAME,
            function () {
                /** @var FileResolverService $fileResolverService */
                $fileResolverService = ServiceRegister::getService(FileResolverService::CLASS_NAME);

                return new CountryLabelService($fileResolverService);
            }
        );

        ServiceRegister::registerService(
            AutoTestService::CLASS_NAME,
            function () {
                return new AutoTestService();
            }
        );
    }

    /**
     * Initializes events.
     */
    protected static function initEvents()
    {
        parent::initEvents();

        /** @var EventBus $eventBuss */
        $eventBuss = ServiceRegister::getService(EventBus::CLASS_NAME);

        // subscribe tick event listener
        $eventBuss->when(
            TickEvent::CLASS_NAME,
            function () {
                $handler = new ScheduleTickHandler();
                $handler->handle();
            }
        );
    }

    /**
     * Initializes the registry of DTO classes.
     *
     * @noinspection PhpUnhandledExceptionInspection
     */
    protected static function initDtoRegistry()
    {
        FrontDtoFactory::register(ValidationError::CLASS_KEY, ValidationError::CLASS_NAME);
        FrontDtoFactory::register(Warehouse::CLASS_KEY, Warehouse::CLASS_NAME);
        FrontDtoFactory::register(ParcelInfo::CLASS_KEY, ParcelInfo::CLASS_NAME);
        FrontDtoFactory::register(DashboardStatus::CLASS_KEY, DashboardStatus::CLASS_NAME);
        FrontDtoFactory::register(Country::CLASS_KEY, Country::CLASS_NAME);
        FrontDtoFactory::register(RegistrationRequest::CLASS_KEY, RegistrationRequest::CLASS_NAME);
        FrontDtoFactory::register(RegistrationLegalPolicy::CLASS_KEY, RegistrationLegalPolicy::CLASS_NAME);
        FrontDtoFactory::register(ShippingPricePolicy::CLASS_KEY, ShippingPricePolicy::CLASS_NAME);
    }
}
