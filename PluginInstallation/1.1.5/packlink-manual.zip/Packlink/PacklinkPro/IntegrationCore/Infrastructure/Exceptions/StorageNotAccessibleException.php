<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions;

/**
 * Class StorageNotAccessibleException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions
 */
class StorageNotAccessibleException extends BaseException
{
}
