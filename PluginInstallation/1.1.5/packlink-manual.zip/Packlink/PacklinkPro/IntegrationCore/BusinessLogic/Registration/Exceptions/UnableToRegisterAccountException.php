<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class UnableToRegisterAccountException
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\Exceptions
 */
class UnableToRegisterAccountException extends BaseException
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
}
