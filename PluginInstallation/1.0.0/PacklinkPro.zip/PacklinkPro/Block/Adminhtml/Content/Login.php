<?php
/**
 * @package    Packlink_PacklinkPro
 * @author     Packlink Shipping S.L.
 * @copyright  2019 Packlink
 */

namespace Packlink\PacklinkPro\Block\Adminhtml\Content;

use Magento\Backend\Block\Template;

/**
 * Class Login
 *
 * @package Packlink\PacklinkPro\Block\Adminhtml\Content
 */
class Login extends Template
{

}
