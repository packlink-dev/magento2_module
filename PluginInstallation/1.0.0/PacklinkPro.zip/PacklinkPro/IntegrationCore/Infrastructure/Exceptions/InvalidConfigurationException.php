<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions;

/**
 * Class InvalidConfigurationException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions
 */
class InvalidConfigurationException extends BaseException
{

}
