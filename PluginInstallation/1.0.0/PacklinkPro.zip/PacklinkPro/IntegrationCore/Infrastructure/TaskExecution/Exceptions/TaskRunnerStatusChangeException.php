<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class TaskRunnerStatusChangeException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerStatusChangeException extends BaseException
{
}
