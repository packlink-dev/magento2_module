<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class DraftNotCreatedException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Exceptions
 */
class DraftNotCreatedException extends BaseException
{
}
