<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Configuration\Configuration;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Interfaces\RepositoryInterface;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\QueryFilter\Operators;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\QueryFilter\QueryFilter;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\RepositoryRegistry;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\QueueService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Models\OrderShipmentDetails;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks\SendDraftTask;

/**
 * Class DraftController
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class DraftController
{
    /**
     * Order details repository instance.
     *
     * @var RepositoryInterface $orderDetailsRepository order details repository.
     */
    protected static $orderDetailsRepository;
    /**
     * QueueService instance.
     *
     * @var QueueService $queue Queue Service.
     */
    protected static $queue;
    /**
     * Configruation instance.
     *
     * @var Configuration $configService Configuration Service.
     */
    protected static $configService;

    /**
     * Creates draft task for provided shop order id.
     *
     * @param string $orderId Shop order id.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryNotRegisteredException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions\QueueStorageUnavailableException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\QueryFilterInvalidParamException
     */
    public static function createDraft($orderId)
    {
        $orderDetails = new OrderShipmentDetails();
        $orderDetails->setOrderId($orderId);
        static::getOrderDetailsRepository()->save($orderDetails);

        $configService = static::getConfigService();
        $draftTask = new SendDraftTask($orderId);
        static::getQueue()->enqueue($configService->getDefaultQueueName(), $draftTask, $configService->getContext());

        if ($draftTask->getExecutionId() !== null) {
            // get again from database since it can happen that task already finished and
            // reference has been set, so we don't delete it here.
            $orderDetails = static::getOrderDetailsByOrderId($orderId);
            if ($orderDetails !== null) {
                $orderDetails->setTaskId($draftTask->getExecutionId());
                static::getOrderDetailsRepository()->update($orderDetails);
            }
        }
    }

    /**
     * Retrieves order details by order id.
     *
     * @param string $orderId Shop order id.
     *
     * @return OrderShipmentDetails | null Order Details instance.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\QueryFilterInvalidParamException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryNotRegisteredException
     */
    protected static function getOrderDetailsByOrderId($orderId)
    {
        $filter = new QueryFilter();
        $filter->where('orderId', Operators::EQUALS, $orderId);

        /** @var OrderShipmentDetails $details */
        $details = static::getOrderDetailsRepository()->selectOne($filter);

        return $details;
    }

    /**
     * Retrieves order details repository.
     *
     * @return RepositoryInterface Order details repository instance.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryNotRegisteredException
     */
    protected static function getOrderDetailsRepository()
    {
        if (static::$orderDetailsRepository === null) {
            static::$orderDetailsRepository = RepositoryRegistry::getRepository(OrderShipmentDetails::getClassName());
        }

        return static::$orderDetailsRepository;
    }

    /**
     * Retrieves queue service.
     *
     * @return QueueService Queue Service instance.
     */
    protected static function getQueue()
    {
        if (static::$queue === null) {
            static::$queue = ServiceRegister::getService(QueueService::CLASS_NAME);
        }

        return static::$queue;
    }

    /**
     * Retrieves configuration service.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Configuration\Configuration Configuration Service instance.
     */
    protected static function getConfigService()
    {
        if (static::$configService === null) {
            static::$configService = ServiceRegister::getService(Configuration::CLASS_NAME);
        }

        return static::$configService;
    }
}