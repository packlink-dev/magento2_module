<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Interfaces\RepositoryInterface;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\RepositoryRegistry;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Singleton;

/**
 * Base class for all services. Initializes service as a singleton instance.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic
 */
abstract class BaseService extends Singleton
{
    /**
     * @noinspection PhpDocMissingThrowsInspection
     *
     * Returns an instance of repository for entity.
     *
     * @param string $entityClass Name of entity class.
     *
     * @return RepositoryInterface Instance of a repository.
     */
    protected function getRepository($entityClass)
    {
        /** @noinspection PhpUnhandledExceptionInspection */
        return RepositoryRegistry::getRepository($entityClass);
    }
}
