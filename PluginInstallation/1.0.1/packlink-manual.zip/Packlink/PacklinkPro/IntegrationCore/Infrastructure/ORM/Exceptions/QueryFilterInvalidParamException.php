<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class QueryFilterInvalidParamException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions
 */
class QueryFilterInvalidParamException extends BaseException
{
}
