<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpBaseException;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\BaseService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\Exceptions\UnableToRegisterAccountException;

/**
 * Class RegistrationService
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration
 */
class RegistrationService extends BaseService
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
    /**
     * Singleton instance of this class.
     *
     * @var static
     */
    protected static $instance;

    /**
     * Registers a new user on Packlink PRO.
     *
     * @param \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\RegistrationRequest $request
     *
     * @return string
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Registration\Exceptions\UnableToRegisterAccountException
     */
    public function register(RegistrationRequest $request)
    {
        try {
            /** @var Proxy $proxy */
            $proxy = ServiceRegister::getService(Proxy::CLASS_NAME);

            return $proxy->register($request->toArray());
        } catch (HttpBaseException $e) {
            throw new UnableToRegisterAccountException(
                'Registration failed. Error: ' . $e->getMessage(),
                $e->getCode()
            );
        }
    }
}
