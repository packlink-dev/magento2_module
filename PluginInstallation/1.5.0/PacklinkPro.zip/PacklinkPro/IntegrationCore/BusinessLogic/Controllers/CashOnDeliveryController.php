<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Logger;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\QueryFilterInvalidParamException;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\CashOnDelivery\Interfaces\CashOnDeliveryServiceInterface;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\CashOnDelivery\Model\CashOnDelivery;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\CashOnDelivery as CashOnDeliveryDTO;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Package;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Objects\Order;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\PackageTransformer;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingCostCalculator;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingMethodService;

class CashOnDeliveryController
{
    /**
     * @var CashOnDeliveryServiceInterface
     */
    protected $cashOnDeliveryService;

    /**
     * @var Configuration
     */
    protected $configuration;

    public function __construct(
    ) {
        $this->cashOnDeliveryService = ServiceRegister::getService(CashOnDeliveryServiceInterface::CLASS_NAME);
        $this->configuration = ServiceRegister::getService(Configuration::CLASS_NAME);
    }

    /**
     * Calculate COD surcharge fee based on Packlink rules.
     *
     * @param Order $order
     *
     * @return float COD surcharge
     * @throws QueryFilterInvalidParamException
     */
    public function calculateFee($order)
    {
        $cod = $this->cashOnDeliveryService->getCashOnDeliveryConfig();

        if($cod && $cod->getAccount() && $cod->getAccount()->getCashOnDeliveryFee() !== null)
        {
            return $cod->getAccount()->getCashOnDeliveryFee();
        }

        $service = $this->getCheapestService($order->getShippingMethodId(), $order);

        if($service && $service->cashOnDeliveryConfig){
            return $this->cashOnDeliveryService->calculateFee($order->getTotalPrice(),
                $service->cashOnDeliveryConfig->applyPercentageCashOnDelivery,
                $service->cashOnDeliveryConfig->maxCashOnDelivery);
        }

        return null;
    }

    /**
     * Saves COD configuration.
     *
     * @param array $rawData
     *
     * @return int ID of saved entity
     * @throws FrontDtoValidationException
     */
    public function saveConfig(array $rawData)
    {
        $dto = CashOnDeliveryDTO::fromArray($rawData);

        return $this->cashOnDeliveryService->saveConfig($dto);
    }

    /**
     * @return  CashOnDeliveryDTO|null $entity
     *
     * @throws QueryFilterInvalidParamException
     */
    public function getCashOnDeliveryConfiguration()
    {
        $cashOnDelivery = $this->cashOnDeliveryService->getCashOnDeliveryConfig();


        if(!$cashOnDelivery) {
            return null;
        }


        return $this->mapEntityToDto($cashOnDelivery);
    }

    /**
     * @param $methodId
     * @param $order
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Models\ShippingService|null
     */
    private function getCheapestService($methodId, $order)
    {
        /** @var ShippingMethodService $shippingService */
        $shippingService = ServiceRegister::getService(ShippingMethodService::CLASS_NAME);
        $shippingMethod = $shippingService->getShippingMethod($methodId);
        if ($shippingMethod !== null) {
            try {
                /** @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Warehouse\Warehouse $warehouse */
                $warehouse = $this->configuration->getDefaultWarehouse();
                $address = $order->getShippingAddress();
                return ShippingCostCalculator::getCheapestShippingService(
                    $shippingMethod,
                    $warehouse->country,
                    $warehouse->postalCode,
                    $address->getCountry(),
                    $address->getZipCode(),
                    $this->getPackage($order)
                );

            } catch (\InvalidArgumentException $e) {
                Logger::logWarning(
                    "Invalid service method $methodId selected for order " . $order->getId()
                    . ' because this method does not support order\'s destination country.'
                );
            }
        }

        return null;
    }
    private function getPackage($order)
    {
        $packages = array();

        foreach ($order->getItems() as $item) {
            $quantity = $item->getQuantity() ?: 1;
            for ($i = 0; $i < $quantity; $i++) {
                $packages[] = new Package(
                    $item->getWeight(),
                    $item->getWidth(),
                    $item->getHeight(),
                    $item->getLength()
                );
            }
        }

        /** @var PackageTransformer $transformer */
        $transformer = ServiceRegister::getService(PackageTransformer::CLASS_NAME);
        return array($transformer->transform($packages));
    }

    /**
     * @param CashOnDelivery $entity
     *
     * @return CashOnDeliveryDTO
     */
    private function mapEntityToDto($entity)
    {
        $dto = new CashOnDeliveryDTO();
        $dto->enabled = $entity->isEnabled();
        $dto->active = $entity->isActive();
        $dto->account = $entity->getAccount();

        return $dto;
    }
}