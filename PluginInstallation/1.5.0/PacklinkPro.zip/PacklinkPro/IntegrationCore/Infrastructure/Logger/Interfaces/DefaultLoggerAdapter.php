<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Interfaces;

/**
 * Interface DefaultLoggerAdapter.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Interfaces
 */
interface DefaultLoggerAdapter extends LoggerAdapter
{
    /**
     * Fully qualified name of this interface.
     */
    const CLASS_NAME = __CLASS__;
}
