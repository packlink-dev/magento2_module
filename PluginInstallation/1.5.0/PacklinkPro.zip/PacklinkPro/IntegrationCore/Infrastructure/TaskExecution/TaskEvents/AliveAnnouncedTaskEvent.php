<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\TaskEvents;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Events\Event;

/**
 * Class AliveAnnouncedTaskEvent.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\TaskEvents
 */
class AliveAnnouncedTaskEvent extends Event
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
}
