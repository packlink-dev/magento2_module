<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Events;

/**
 * Class Event.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Events
 */
abstract class Event
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
}
