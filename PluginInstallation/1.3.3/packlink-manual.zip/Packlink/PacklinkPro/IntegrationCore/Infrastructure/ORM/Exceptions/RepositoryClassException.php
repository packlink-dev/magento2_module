<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class RepositoryClassException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions
 */
class RepositoryClassException extends BaseException
{
}
