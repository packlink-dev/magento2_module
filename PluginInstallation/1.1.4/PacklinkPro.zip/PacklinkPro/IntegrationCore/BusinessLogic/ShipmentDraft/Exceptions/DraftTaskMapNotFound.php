<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShipmentDraft\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class DraftTaskMapNotFound.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShipmentDraft\Exceptions
 */
class DraftTaskMapNotFound extends BaseException
{
}
