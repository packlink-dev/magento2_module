<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\User;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpBaseException;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Logger\Logger;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Interfaces\RepositoryInterface;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\RepositoryRegistry;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\QueueService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\BaseService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\CountryService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Analytics;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\User;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Scheduler\Models\Schedule;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Scheduler\Models\WeeklySchedule;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks\UpdateShippingServicesTask;

/**
 * Class UserAccountService.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\User
 */
class UserAccountService extends BaseService
{
    /**
     * Fully qualified name of this interface.
     */
    const CLASS_NAME = __CLASS__;
    /**
     * Singleton instance of this class.
     *
     * @var static
     */
    protected static $instance;
    /**
     * Configuration service instance.
     *
     * @var Configuration
     */
    protected $configuration;
    /**
     * Proxy instance.
     *
     * @var Proxy
     */
    private $proxy;

    /**
     * Validates provided API key and initializes user's data.
     *
     * @param string $apiKey API key.
     *
     * @return bool TRUE if login went successfully; otherwise, FALSE.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryNotRegisteredException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions\QueueStorageUnavailableException
     */
    public function login($apiKey)
    {
        if (empty($apiKey)) {
            return false;
        }

        // set token before calling API
        $this->getConfigService()->setAuthorizationToken($apiKey);

        try {
            $userDto = $this->getProxy()->getUserData();
            $this->initializeUser($userDto);
        } catch (HttpBaseException $e) {
            $this->getConfigService()->resetAuthorizationCredentials();
            Logger::logError($e->getMessage());

            return false;
        }

        $this->createSchedules();
        $this->getConfigService()->setFirstShipmentDraftCreated(false);

        return true;
    }

    /**
     * Sets default parcel information.
     *
     * @param bool $force Force retrieval of parcel info from Packlink API.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpBaseException
     */
    public function setDefaultParcel($force)
    {
        $parcelInfo = $this->getConfigService()->getDefaultParcel();
        if ($parcelInfo === null || $force) {
            if ($this->setParcelInfoInternal()) {
                return;
            }

            $parcels = $this->getProxy()->getUsersParcelInfo();
            foreach ($parcels as $parcel) {
                if ($parcel->default) {
                    $parcelInfo = $parcel;
                    break;
                }
            }

            if ($parcelInfo !== null) {
                $this->getConfigService()->setDefaultParcel($parcelInfo);
            }
        }
    }

    /**
     * Sets warehouse information.
     *
     * @param bool $force Force retrieval of warehouse info from Packlink API.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     */
    public function setWarehouseInfo($force)
    {
        $warehouse = $this->getConfigService()->getDefaultWarehouse();
        if ($warehouse === null || $force) {
            if ($this->setWarehouseInfoInternal()) {
                return;
            }

            $usersWarehouses = $this->getProxy()->getUsersWarehouses();
            foreach ($usersWarehouses as $usersWarehouse) {
                if ($usersWarehouse->default) {
                    $warehouse = $usersWarehouse;
                    break;
                }
            }

            if ($warehouse !== null) {
                /** @var CountryService $countryService */
                $countryService = ServiceRegister::getService(CountryService::CLASS_NAME);

                if ($countryService->isCountrySupported($warehouse->country)) {
                    $this->getConfigService()->setDefaultWarehouse($warehouse);
                } else {
                    Logger::logWarning('Warehouse country not supported', 'Core');
                }
            }
        }
    }

    /**
     * Initializes user configuration and subscribes web-hook callback.
     *
     * @param User $user User data.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpBaseException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions\QueueStorageUnavailableException
     */
    protected function initializeUser(User $user)
    {
        $this->getConfigService()->setUserInfo($user);
        $defaultQueueName = $this->getConfigService()->getDefaultQueueName();

        /** @var QueueService $queueService */
        $queueService = ServiceRegister::getService(QueueService::CLASS_NAME);

        $this->setDefaultParcel(true);
        $this->setWarehouseInfo(true);

        if ($this->getConfigService()->getDefaultWarehouse() !== null) {
            $queueService->enqueue(
                $defaultQueueName,
                new UpdateShippingServicesTask(),
                $this->getConfigService()->getContext()
            );
        }

        $webHookUrl = $this->getConfigService()->getWebHookUrl();
        if (!empty($webHookUrl)) {
            $this->getProxy()->registerWebHookHandler($webHookUrl);
        }

        $this->getProxy()->sendAnalytics(Analytics::EVENT_CONFIGURATION);
    }

    /**
     * Internal method for setting warehouse info in integrations.
     * If integration set it, Core will not fetch the info from Packlink API.
     *
     * @return bool
     */
    protected function setWarehouseInfoInternal()
    {
        return false;
    }

    /**
     * Internal method for setting default parcel info in integrations.
     * If integration set it, Core will not fetch the info from Packlink API.
     *
     * @return bool
     */
    protected function setParcelInfoInternal()
    {
        return false;
    }

    /**
     * Creates schedules.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryNotRegisteredException
     */
    protected function createSchedules()
    {
        $repository = RepositoryRegistry::getRepository(Schedule::CLASS_NAME);

        $this->scheduleUpdateShipmentServicesTask($repository);
    }

    /**
     * @param \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Interfaces\RepositoryInterface $repository
     *
     */
    protected function scheduleUpdateShipmentServicesTask(RepositoryInterface $repository)
    {
        // Schedule weekly task for updating services
        $schedule = new WeeklySchedule(
            new UpdateShippingServicesTask(),
            $this->getConfigService()->getDefaultQueueName(),
            $this->getConfigService()->getContext()
        );

        $schedule->setDay(rand(1, 7));
        $schedule->setHour(rand(0, 5));
        $schedule->setMinute(rand(0, 59));
        $schedule->setNextSchedule();
        $repository->save($schedule);
    }

    /**
     * Gets Proxy.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy Proxy.
     */
    protected function getProxy()
    {
        if ($this->proxy === null) {
            $this->proxy = ServiceRegister::getService(Proxy::CLASS_NAME);
        }

        return $this->proxy;
    }

    /**
     * Returns an instance of configuration service.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration Configuration service.
     */
    protected function getConfigService()
    {
        if ($this->configuration === null) {
            $this->configuration = ServiceRegister::getService(Configuration::CLASS_NAME);
        }

        return $this->configuration;
    }
}
