<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class QueueItemDeserializationException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions
 */
class QueueItemDeserializationException extends BaseException
{
}
