<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Task;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\User\UserAccountService;

/**
 * Class GetDefaultParcelAndWarehouseTask
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks
 */
class GetDefaultParcelAndWarehouseTask extends Task
{
    /**
     * Transforms array into an serializable object,
     *
     * @param array $array Data that is used to instantiate serializable object.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Serializer\Interfaces\Serializable
     *      Instance of serialized object.
     */
    public static function fromArray(array $array)
    {
        return new static();
    }

    /**
     * Transforms serializable object into an array.
     *
     * @return array Array representation of a serializable object.
     */
    public function toArray()
    {
        return array();
    }

    /**
     * Runs task logic.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpBaseException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     */
    public function execute()
    {
        /** @var UserAccountService $userAccountService */
        $userAccountService = ServiceRegister::getService(UserAccountService::CLASS_NAME);

        $userAccountService->setDefaultParcel(true);
        $this->reportProgress(50);

        $userAccountService->setWarehouseInfo(true);
        $this->reportProgress(100);
    }
}
