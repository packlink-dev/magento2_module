<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\OrderShipmentDetails\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class OrderShipmentDetailsNotFound.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\OrderShipmentDetails\Exceptions
 */
class OrderShipmentDetailsNotFound extends BaseException
{
}
