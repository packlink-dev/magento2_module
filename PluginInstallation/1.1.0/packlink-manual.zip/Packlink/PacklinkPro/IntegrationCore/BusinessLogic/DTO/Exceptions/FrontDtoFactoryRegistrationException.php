<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class FrontDtoFactoryRegistrationException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions
 */
class FrontDtoFactoryRegistrationException extends BaseException
{
}
