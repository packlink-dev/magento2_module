<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Task;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\Country;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\CountryService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Package;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ParcelInfo;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ShippingServiceDetails;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ShippingServiceSearch;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Models\ShippingMethod;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Models\ShippingService;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingMethodService;

/**
 * Task to update available shipping services and their default costs.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks
 */
class UpdateShippingServicesTask extends Task
{
    /**
     * @var CountryService
     */
    private $countryService;

    /**
     * Transforms array into an serializable object,
     *
     * @param array $array Data that is used to instantiate serializable object.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Serializer\Interfaces\Serializable
     *      Instance of serialized object.
     */
    public static function fromArray(array $array)
    {
        return new static();
    }

    /**
     * Transforms serializable object into an array.
     *
     * @return array Array representation of a serializable object.
     */
    public function toArray()
    {
        return array();
    }

    /**
     * Gets all local methods and remote services and synchronizes data.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException
     */
    public function execute()
    {
        $this->reportProgress(1);

        if ($this->shouldExecute()) {
            $apiServices = $this->getRemoteServices();
            $currentMethods = $this->getShippingMethodService()->getAllMethods();

            $this->reportProgress(20);
            $this->syncServices($currentMethods, $apiServices);
        }

        $this->reportProgress(100);
    }

    /**
     * Gets all available services for current user.
     *
     * @return array Key is service Id and value is @see \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ShippingServiceDetails object.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException
     */
    protected function getRemoteServices()
    {
        /** @var Configuration $config */
        $config = ServiceRegister::getService(Configuration::CLASS_NAME);

        $warehouse = $config->getDefaultWarehouse();
        if ($warehouse !== null) {
            $sourceCountryCode = $warehouse->country;
        } else {
            $sourceCountryCode = $config->getUserInfo()->country;
        }

        $supportedCountries = $this->getSupportedCountriesForServices();
        $sourceCountry = $supportedCountries[$sourceCountryCode];

        $parcel = $config->getDefaultParcel() ?: ParcelInfo::defaultParcel();
        $package = Package::fromArray($parcel->toArray());

        $allServices = array();
        foreach ($supportedCountries as $country) {
            $this->setServices(
                $allServices,
                new ShippingServiceSearch(
                    null,
                    $sourceCountry->code,
                    $sourceCountry->postalCode,
                    $country->code,
                    $country->postalCode,
                    array($package)
                )
            );
        }

        return $allServices;
    }

    /**
     * Sets shipping services from Packlink API.
     *
     * @param array $allServices Key is service ID, value is an array with keys 'service' and 'serviceDetails'.
     * @param ShippingServiceSearch $searchParams Details for which to search for services.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     */
    protected function setServices(array &$allServices, ShippingServiceSearch $searchParams)
    {
        $proxy = $this->getProxy();
        $serviceDeliveryDetails = $proxy->getShippingServicesDeliveryDetails($searchParams);
        foreach ($serviceDeliveryDetails as $deliveryDetail) {
            $allServices[] = $deliveryDetail;
        }
    }

    /**
     * Creates, updates or deletes local shipping methods based on state on Packlink API.
     *
     * @param array $currentMethods Current shipping methods in shop.
     * @param array $apiServices Services retrieved from API.
     */
    protected function syncServices(array $currentMethods, array $apiServices)
    {
        $progress = 20;
        $progressStep = count($currentMethods) > 0 ? (60 / count($currentMethods)) : 60;

        foreach ($currentMethods as $shippingMethod) {
            $this->updateShippingMethod($shippingMethod, $apiServices);

            $progress += $progressStep;
            $this->reportProgress($progress);
        }

        $this->reportProgress(80);
        foreach ($apiServices as $service) {
            $this->getShippingMethodService()->add($service);
        }
    }

    /**
     * Updates shipping method from data from Packlink API or deletes it if service does not exist.
     *
     * @param ShippingMethod $shippingMethod Local shipping method.
     * @param ShippingServiceDetails[] $apiServices Shipping services returned from API.
     */
    protected function updateShippingMethod(ShippingMethod $shippingMethod, array &$apiServices)
    {
        $shippingServices = array();
        foreach ($apiServices as $service) {
            if ($this->serviceBelongsToMethod($service, $shippingMethod)) {
                $shippingServices[] = ShippingService::fromServiceDetails($service);
            }
        }

        if (!empty($shippingServices)) {
            $shippingMethod->setShippingServices($shippingServices);
            $this->getShippingMethodService()->save($shippingMethod);

            /** @var ShippingService $service */
            foreach ($shippingServices as $service) {
                unset($apiServices[$service->serviceId]);
            }

            return;
        }

        $this->getShippingMethodService()->delete($shippingMethod);
    }

    /**
     * Checks if task should be executed.
     *
     * @return bool TRUE if task should execute; otherwise, FALSE.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException
     */
    protected function shouldExecute()
    {
        /** @var Configuration $config */
        $config = ServiceRegister::getService(Configuration::CLASS_NAME);
        $userInfo = $config->getUserInfo();

        if ($userInfo === null) {
            return false;
        }

        $supportedCountries = $this->getSupportedCountriesForServices();

        return $config->getDefaultWarehouse() !== null || array_key_exists($userInfo->country, $supportedCountries);
    }

    /**
     * Returns supported countries for available services.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\Country[]
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\Exceptions\FrontDtoValidationException
     */
    protected function getSupportedCountriesForServices()
    {
        $supportedCountries = $this->getCountryService()->getSupportedCountries();
        $supportedCountries['US'] = Country::fromArray(
            array(
                'name' => 'United States',
                'code' => 'US',
                'postal_code' => '10001',
                'registration_link' => 'https://pro.packlink.com/register',
            )
        );

        return $supportedCountries;
    }

    /**
     * Gets instance of shipping method service.
     *
     * @return ShippingMethodService Shipping method service.
     */
    protected function getShippingMethodService()
    {
        /** @var ShippingMethodService $shippingMethodService */
        $shippingMethodService = ServiceRegister::getService(ShippingMethodService::CLASS_NAME);

        return $shippingMethodService;
    }

    /**
     * Gets instance of Packlink proxy.
     *
     * @return Proxy Proxy instance.
     */
    protected function getProxy()
    {
        /** @var Proxy $proxy */
        /** @noinspection OneTimeUseVariablesInspection */
        $proxy = ServiceRegister::getService(Proxy::CLASS_NAME);

        return $proxy;
    }

    /**
     * Checks if given shipping service belongs to given shipping method.
     *
     * @param \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\ShippingServiceDetails $service Shipping service from API.
     *
     * @param \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\Models\ShippingMethod $shippingMethod Shipping method from system.
     *
     * @return bool TRUE if given shipping service belongs to given shipping method; otherwise, FALSE.
     */
    protected function serviceBelongsToMethod(ShippingServiceDetails $service, ShippingMethod $shippingMethod)
    {
        return $service->carrierName === $shippingMethod->getCarrierName()
            && $service->national === $shippingMethod->isNational()
            && $service->expressDelivery === $shippingMethod->isExpressDelivery()
            && $service->departureDropOff === $shippingMethod->isDepartureDropOff()
            && $service->destinationDropOff === $shippingMethod->isDestinationDropOff();
    }

    /**
     * Returns an instance of country service.
     *
     * @return \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\CountryService
     */
    protected function getCountryService()
    {
        if ($this->countryService === null) {
            $this->countryService = ServiceRegister::getService(CountryService::CLASS_NAME);
        }

        return $this->countryService;
    }
}
