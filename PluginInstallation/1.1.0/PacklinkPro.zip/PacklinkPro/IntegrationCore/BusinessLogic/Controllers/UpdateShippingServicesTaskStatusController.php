<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\QueryFilter\Operators;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\QueryFilter\QueryFilter;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\RepositoryRegistry;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\QueueItem;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\TimeProvider;

/**
 * Class UpdateShippingServicesTaskStatusController.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class UpdateShippingServicesTaskStatusController
{
    /**
     * Checks the status of the task responsible for getting services.
     *
     * @return string <p>One of the following statuses:
     *  QueueItem::FAILED - when the task failed,
     *  QueueItem::COMPLETED - when the task completed successfully,
     *  QueueItem::IN_PROGRESS - when the task is in progress,
     *  QueueItem::QUEUED - when the default warehouse is not set by user and the task was not enqueued.
     * </p>
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\QueryFilterInvalidParamException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryClassException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions\RepositoryNotRegisteredException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions\QueueItemDeserializationException
     */
    public function getLastTaskStatus()
    {
        $repo = RepositoryRegistry::getQueueItemRepository();
        $filter = new QueryFilter();
        $filter->where('taskType', Operators::EQUALS, 'UpdateShippingServicesTask');
        $filter->orderBy('queueTime', 'DESC');

        $item = $repo->selectOne($filter);
        if ($item) {
            $status = $item->getStatus();
            if ($status === QueueItem::FAILED || $status === QueueItem::COMPLETED) {
                return $status;
            }

            /** @var TimeProvider $timeProvider */
            $timeProvider = ServiceRegister::getService(TimeProvider::CLASS_NAME);
            $currentTimestamp = $timeProvider->getCurrentLocalTime()->getTimestamp();
            $taskTimestamp = $item->getLastUpdateTimestamp() ?: $item->getQueueTimestamp();
            $expired = $taskTimestamp + $item->getTask()->getMaxInactivityPeriod() < $currentTimestamp;

            return $expired ? QueueItem::FAILED : $status;
        }

        return QueueItem::QUEUED;
    }
}
