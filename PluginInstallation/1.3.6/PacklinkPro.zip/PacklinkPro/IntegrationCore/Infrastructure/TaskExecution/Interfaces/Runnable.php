<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Serializer\Interfaces\Serializable;

/**
 * Interface Runnable.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces
 */
interface Runnable extends Serializable
{
    /**
     * Starts runnable run logic
     */
    public function run();
}
