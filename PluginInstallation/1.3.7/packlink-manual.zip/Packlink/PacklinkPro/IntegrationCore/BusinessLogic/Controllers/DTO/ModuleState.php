<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO;

use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\DTO\FrontDto;

/**
 * Class ModuleState.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO
 */
class ModuleState extends FrontDto
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;

    /**
     * Login state key.
     */
    const LOGIN_STATE = 'login';

    /**
     * On-boarding state key.
     */
    const ONBOARDING_STATE = 'onBoarding';

    /**
     * Service state key.
     */
    const SERVICES_STATE = 'services';

    /**
     * @var string Current state.
     */
    public $state;

    /**
     * Fields for this DTO. Needed for validation and transformation from/to array.
     *
     * @var array
     */
    protected static $fields = array(
        'state',
    );
}
