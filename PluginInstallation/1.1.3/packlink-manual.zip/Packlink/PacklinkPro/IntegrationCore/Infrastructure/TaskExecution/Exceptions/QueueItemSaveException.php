<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class QueueItemSaveException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions
 */
class QueueItemSaveException extends BaseException
{
}
