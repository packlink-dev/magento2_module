<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\CountryService;

/**
 * Class RegistrationRegionsController
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class RegistrationRegionsController
{
    /**
     * Country service.
     *
     * @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Country\CountryService
     */
    private $service;

    /**
     * RegistrationRegionsController constructor.
     */
    public function __construct()
    {
        $this->service = ServiceRegister::getService(CountryService::CLASS_NAME);
    }

    public function getRegions()
    {
        return $this->service->getSupportedCountries(false);
    }
}