<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO\OnboardingState;

class OnboardingController
{
    /**
     * Gets current state of the on-boarding page.
     *
     * @return OnboardingState
     */
    public function getCurrentState()
    {
        $result = new OnboardingState();

        /** @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration $configService */
        $configService = ServiceRegister::getService(Configuration::CLASS_NAME);

        $parcel = $configService->getDefaultParcel();
        $warehouse = $configService->getDefaultWarehouse();

        if ($parcel === null && $warehouse === null) {
            $result->state = OnboardingState::WELCOME_STATE;

        } else {
            $result->state = OnboardingState::OVERVIEW_STATE;
        }

        return $result;
    }
}
